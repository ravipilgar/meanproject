import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ant',
  templateUrl: './ant.component.html',
  styleUrls: ['./ant.component.css']
})
export class AntComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
