import { Component, OnInit } from '@angular/core';
declare const load: any;

@Component({
  selector: 'app-syn',
  templateUrl: './syn.component.html',
  styleUrls: ['./syn.component.css']
})
export class SynComponent implements OnInit {

  constructor() { }
  myfun() {

  }

  ngOnInit(): void {
  }

}
