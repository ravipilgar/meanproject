import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BnnerComponent } from './bnner.component';

describe('BnnerComponent', () => {
  let component: BnnerComponent;
  let fixture: ComponentFixture<BnnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BnnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BnnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
